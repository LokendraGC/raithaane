<?php
  /*
   * Template name: Registration Form
   */
?>

<?php if(is_user_logged_in()){
  wp_redirect(get_permalink(get_option('woocommerce_myaccount_page_id')));
} ?>
<?php get_header();?>

<?php get_template_part('template-parts/common/banner-section'); ?>

<div class="section-seperator bg_light-1">
	<div class="container">
		<hr class="section-seperator">
	</div>
</div>  
<div class="rts-cart-area rts-section-gap bg_light-1">
	<div class="container">
	<div class="row">
	<div class="col-lg-12">
<?php do_action( 'woocommerce_before_customer_login_form' ); ?>

<div class="registration-wrapper-1">
<?php $logo = get_field('wtn_header_logo', 'options'); ?>
	<div class="logo-area mb--0">
		<img src="<?php echo ($logo) ? $logo['url'] : get_template_directory_uri() . '/assets/images/raithaane-logo.svg'; ?>" alt="<?php echo bloginfo('sitename'); ?>">
	</div>

	<h2><?php esc_html_e( 'Register Into Your Account', 'woocommerce' ); ?></h2>
	<form method="post" class="woocommerce-form woocommerce-form-register register registration-form" <?php do_action( 'woocommerce_register_form_tag' ); ?> >
		<?php do_action( 'woocommerce_register_form_start' ); ?>
		<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>
		<?php endif; ?>
		<div class="input-wrapper">
			<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
			<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
		</div>
		<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
		<div class="input-wrapper">
			<label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
			<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
		</div>
		<?php else : ?>
			<p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce' ); ?></p>
		<?php endif; ?>
		<?php do_action( 'woocommerce_register_form' ); ?>
		<p class="woocommerce-form-row form-row">
			<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
			<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit rts-btn btn-primary" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
		</p>
		<?php do_action( 'woocommerce_register_form_end' ); ?>
		<div class="another-way-to-registration">
			<div class="registradion-top-text">
				<span>Or Login</span>
			</div>
			<p>Already Have Account? <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>">Login</a></p>
		</div>
	</form>
</div>
</div>
</div>
<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
</div>
</div>
<?php get_footer();